import React, { useEffect, useState } from "react";
import { List, InfiniteScroll, SearchBar } from "antd-mobile";
import { getPaginatedUsers, searchUsers } from "../../services/api"; // ✅ Import both

import NewProfileCard from "./NewProfileCard";

const Profiles = ({ adminProp }) => {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [inputValue, setInputValue] = useState("");
  const [search, setSearch] = useState("");

  const limit = 10;

  const fetchUsers = async (pageNum = 0, searchQuery = "") => {
    try {
      const start = pageNum * limit;
      const data = searchQuery
        ? await searchUsers(searchQuery, start, limit)
        : await getPaginatedUsers(start, limit);
  
      const userList = data?.data || data || [];
  
      if (userList.length === 0) {
        setHasMore(false);
      } else {
        setUsers((prev) => (pageNum === 0 ? userList : [...prev, ...userList]));
        setPage(pageNum + 1);
      }
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  useEffect(() => {
    const handler = setTimeout(() => {
      setSearch(inputValue);
    }, 300);

    return () => clearTimeout(handler);
  }, [inputValue]);

  // ✅ Fetch when search changes
  useEffect(() => {
    setUsers([]);
    setPage(0);
    setHasMore(true);
    fetchUsers(0, search);
  }, [search]);

  return (
    <div>
      <SearchBar
        key="UniqueKey"
        placeholder="Search Users..."
        value={inputValue}
        onChange={val => setInputValue(val)}
        style={{ marginBottom: 10, padding: "16px" }}
      />

      <List>
        {users.map((user) => (
          <NewProfileCard key={user.id} user={user} adminProp={adminProp} />
        ))}
      </List>

      <InfiniteScroll loadMore={() => fetchUsers(page, search)} hasMore={hasMore} />
    </div>
  );
};

export default Profiles;
