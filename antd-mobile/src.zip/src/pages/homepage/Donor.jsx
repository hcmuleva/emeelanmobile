import React from 'react'

export default function Donor() {
  return (
    <div>
      Donor
    </div>
  )
}
