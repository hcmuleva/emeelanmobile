import React from 'react'

export default function Admins() {
  return (
    <div>
      Admins List
    </div>
  )
}
