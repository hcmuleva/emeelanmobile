import React from 'react'
import Profiles from '../../components/users/Profiles'

export default function ProfilesPage() {
  return (
    <div>
      <Profiles/>
    </div>
  )
}
