import React from 'react'
import ProfileStatus from '../components/users/ProfileStatus'
import MobileImageUploader from '../components/authentication/registration/MobileImageUploader'

export default function Chat() {
  return (
    <div>
      chat
      <ProfileStatus/>
    </div>
  )
}
