import React from 'react'
import ProfileStatus from '../components/users/ProfileStatus'

export default function Chat() {
  return (
    <div>
      chat
      <ProfileStatus/>
    </div>
  )
}
