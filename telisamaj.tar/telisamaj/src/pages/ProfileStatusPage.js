import React from 'react'
import ProfileStatus from '../components/users/ProfileStatus'

export default function ProfileStatusPage() {
  return (
    <div>
      <ProfileStatus/>
    </div>
  )
}
