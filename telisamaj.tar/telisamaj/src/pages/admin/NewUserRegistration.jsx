import React from 'react'
import RegisterUser from '../../components/admin/RegisterUser'

export default function NewUserRegistration() {
  return (
    <div>
     <RegisterUser/>
    </div>
  )
}
