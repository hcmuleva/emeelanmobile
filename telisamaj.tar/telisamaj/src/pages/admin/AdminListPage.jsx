import React from 'react'
import AdminList from '../../components/admin/AdminList'

export default function AdminListPage() {
  return (
    <div>
      <AdminList />
    </div>
  )
}
