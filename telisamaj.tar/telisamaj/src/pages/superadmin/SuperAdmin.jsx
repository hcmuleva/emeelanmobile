import React from 'react'

export default function SuperAdmin() {
  return (
    <div>
      SuperAdmin
    </div>
  )
}
