import React from "react";
import FeatureTiles from "./homepage/FeatureTiles";

const Home = () => {
    return (
        <FeatureTiles/>
    );
};

export default Home;
