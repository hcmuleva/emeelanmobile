import React from 'react'

export default function ProfileSettings() {
  return (
    <div>
      Profile Settings
    </div>
  )
}
