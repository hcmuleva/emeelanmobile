import React from 'react'

export default function FamilyData() {
  return (
    <div>
      FamilyData
    </div>
  )
}
