import React from 'react'

export default function Profession() {
  return (
    <div>
       Profession Settings
    </div>
  )
}
