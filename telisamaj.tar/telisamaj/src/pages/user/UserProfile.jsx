import React from 'react';
import ProfileDetails from './ProfileDetails';

const UserProfile = () => {
  return <ProfileDetails/>
}

export default UserProfile