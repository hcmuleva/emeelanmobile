import React from 'react'

export default function UserStatusPage() {
  return (
    <div>
      User Statsu Page
    </div>
  )
}
