import enUS from 'antd-mobile/es/locales/en-US';

export default {
  ...enUS,
  app: {
    login: 'Login',
    register: 'Register',
    welcome: 'Welcome',
    // Add your custom English translations here
  }
};