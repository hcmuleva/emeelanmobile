// src/services/utils/helpers.js

export const buildPopulateQuery = (fields, options = {}) => {
    // ... existing implementation ...
  };
  
  export const parseSortParam = (sortParam) => {
    // ... existing implementation ...
  };
  
  export const buildFilterQuery = (filters = {}) => {
    // ... existing implementation ...
  };
  
  const helpers = {
    buildPopulateQuery,
    parseSortParam,
    buildFilterQuery
  };
  
  export default helpers;