// components/Profile/index.js (recommended for barrel files)
export { default as BasicInfoCard } from './BasicInfo';
export { default as Education } from './EducationInfo';
export { default as ActionButtons } from './ActionButtons';