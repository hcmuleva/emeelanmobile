import React from 'react'

export default function AdminActions() {
  return (
    <div>
      
    </div>
  )
}
