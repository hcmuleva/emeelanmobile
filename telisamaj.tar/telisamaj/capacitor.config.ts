import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.emeelan.mastjod',
  appName: 'Emeelan',
  webDir: 'build',
  
  
};

export default config;
